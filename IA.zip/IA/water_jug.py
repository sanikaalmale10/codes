from collections import deque

# Function to find a solution to the water jug problem
def water_jug_problem(jug1_capacity, jug2_capacity, target):
    # Initialize a queue for BFS and a set for visited states
    queue = deque()
    visited = set()

    # Initial state with both jugs empty
    queue.append((0, 0))
    visited.add((0, 0))

    # While there are still states to explore
    while queue:
        jug1, jug2 = queue.popleft()

        # If we achieve the target, return the solution path
        if jug1 == target or jug2 == target or jug1 + jug2 == target:
            return f"Target achieved with {jug1} in jug1 and {jug2} in jug2."

        # List of possible operations to consider
        possible_operations = [
            # Fill jug1
            (jug1_capacity, jug2),
            # Fill jug2
            (jug1, jug2_capacity),
            # Empty jug1
            (0, jug2),
            # Empty jug2
            (jug1, 0),
            # Pour jug1 into jug2
            (max(0, jug1 - (jug2_capacity - jug2)), min(jug2_capacity, jug2 + jug1)),
            # Pour jug2 into jug1
            (min(jug1_capacity, jug1 + jug2), max(0, jug2 - (jug1_capacity - jug1))),
        ]

        # For each possible operation, add the resulting state to the queue if it's new
        for new_state in possible_operations:
            if new_state not in visited:
                queue.append(new_state)
                visited.add(new_state)

    return "No solution found."

# Test the function with some example values
jug1_capacity = 4  # capacity of jug1
jug2_capacity = 3  # capacity of jug2
target = 2  # the target amount of water to measure

result = water_jug_problem(jug1_capacity, jug2_capacity, target)
print(result)  # Expected output: "Target achieved with 2 in jug1 and 0 in jug2."
